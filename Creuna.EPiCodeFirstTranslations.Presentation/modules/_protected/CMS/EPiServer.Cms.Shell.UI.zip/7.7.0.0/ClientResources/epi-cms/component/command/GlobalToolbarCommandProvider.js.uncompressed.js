﻿define("epi-cms/component/command/GlobalToolbarCommandProvider", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",

    "dijit/form/ToggleButton",
    "dijit/layout/ContentPane",

    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",

    "epi/shell/ViewSettings",

    "epi/shell/widget/ExpandoButton",

    "epi-cms/command/CompareCommand",
    "epi-cms/widget/ViewSettingsExpandoButton",
    "epi-cms/widget/VisitorGroupButton",
    "epi-cms/widget/ChannelsButton",
    "epi-cms/widget/ViewLanguageButton",
    "epi-cms/widget/command/CreateContentFromSelector",
    "dijit/Destroyable",

    "epi-cms/component/command/_GlobalToolbarCommandProvider",

    "epi-cms/_SidePanelsToggleMixin",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"
], function(
    array,
    declare,
    lang,
    topic,

    ToggleButton,
    ContentPane,

    dependency,
    _Command,
    ToggleCommand,

    ViewSettings,

    ExpandoButton,

    CompareCommand,
    ViewSettingsExpandoButton,
    VisitorGroupButton,
    ChannelsButton,
    ViewLanguageButton,
    CreateContentFromSelector,
    Destroyable,

    _GlobalToolbarCommandProvider,
    _SidePanelsToggleMixin,

    resources
) {

    var _ToggleNavigationPaneCommand = declare([ToggleCommand, Destroyable], {
        iconClass: "epi-iconTree",
        tooltip: resources.toolbar.buttons.togglenavigationpane,
        label: resources.toolbar.buttons.togglenavigationpane,
        canExecute: true,
        constructor: function () {
            this.own(
                topic.subscribe("/epi/layout/pinnable/navigation/visibilitychanged", lang.hitch(this, function (visible) {
                    this.set("active", visible);
                }))
            );
        },
        _execute: function () {
            topic.publish("/epi/layout/pinnable/navigation/toggle");
        }

    });

    var _ToggleAssetsPaneCommand = declare([ToggleCommand, Destroyable], {
        iconClass: "epi-iconFolder",
        tooltip: resources.toolbar.buttons.toggleassetspane,
        label: resources.toolbar.buttons.toggleassetspane,
        canExecute: true,
        constructor: function () {
            this.own(
                topic.subscribe("/epi/layout/pinnable/tools/visibilitychanged", lang.hitch(this, function (visible) {
                    this.set("active", visible);
                }))
            );
        },
        _execute: function () {
            topic.publish("/epi/layout/pinnable/tools/toggle");
        }
    });

    var _ViewSettingCommand = declare([_Command, Destroyable], {
        iconClass: "epi-iconEye",
        canExecute: true,
        label: resources.toolbar.buttons.viewsetting.viewsettingbutton,

        constructor: function () {
            this.own(
                topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (type, args, data) {
                    // Close the view settings button when compare becomes active.
                    var view = data && data.viewName;
                    if (view === "compare") {
                        this.set("active", false);
                    }
                    // Hide the view settings button if not in edit mode.
                    this.set("isAvailable", type === "epi-cms/contentediting/PageDataController");
                }))
            );
        }
    });

    var _TogglePreviewModeCommand = declare([ToggleCommand, _SidePanelsToggleMixin, Destroyable], {
        iconClass: "epi-iconPreview",
        tooltip: resources.toolbar.buttons.togglepreviewmode.label,
        label: resources.toolbar.buttons.togglepreviewmode.label,
        canExecute: true,

        constructor: function() {
            this.own(
                // Deactivate the option if we recieve a disable topic.
                topic.subscribe("/epi/cms/action/disablepreview", lang.hitch(this, "_deactivate")),

                topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (type, args, data) {
                    // Close the preview view if another view is opened.
                    var view = data && data.viewName;
                    if (view !== "view") {
                        this._deactivate();
                    }
                    // Hide the view settings button if not in edit mode.
                    this.set("isAvailable", type === "epi-cms/contentediting/PageDataController");
                }))
            );
        },

        _execute: function () {
            this.set("active", !this.active);

            if (this.active) {
                topic.publish("/epi/shell/action/changeview", "view");
                this._hideSidePanels();
            } else {
                this._restoreSidePanels();
                topic.publish("/epi/shell/action/changeview/back", true);
            }
        },

        _deactivate: function() {
            if (this.active) {
                this.set("active", false);
                this._restoreSidePanels();
                topic.publish("/epi/shell/action/changeview/deactivate", "view");
            }
        }
    });

    // module:
    //      epi-cms/component/command/GlobalToolbarCommandProvider
    // summary:
    //      Default command provider for the epi-cms/component/GlobalToolbar
    // tags:
    //      private
    return declare([_GlobalToolbarCommandProvider], {

        contentRepositoryDescriptors: null,
        viewName: null,

        postscript: function () {
            // summary:
            //      Ensure that an array of commands has been initialized.
            // tags:
            //      public
            this.inherited(arguments);

            this.contentRepositoryDescriptors = this.contentRepositoryDescriptors || dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.viewName = this.viewName || ViewSettings.viewName;
            this._addLeadingCommands();

            this._addCreateCommands();

            this._addViewCommands();

            this._addTrailingCommands();
        },

        _addLeadingCommands: function () {
            this.addToLeading(new _ToggleNavigationPaneCommand(), {
                widget: ToggleButton,
                "class": "epi-leadingToggleButton epi-mediumButton"
            });
        },

        _addCreateCommands: function () {

            var currentView = this.viewName;
            var descriptorsForCurrentView = [];
            var isCurrentView = function(view) {
                return view == currentView;
            };

            for (var index in this.contentRepositoryDescriptors) {
                var descriptor = this.contentRepositoryDescriptors[index];
                if (array.some(descriptor.mainViews, isCurrentView)) {
                    descriptorsForCurrentView.push(descriptor);
                }
            }

            array.forEach(descriptorsForCurrentView, function(descriptor) {
                array.forEach(descriptor.creatableTypes, function(type) {
                    this.addCommand(this._createCommand(type), { category: "create" });
                }, this);
            }, this);
        },

        _createCommand: function(type) {
            return new CreateContentFromSelector({
                creatingTypeIdentifier: type
            });
        },

        _addViewCommands: function () {
            // View settings expando button
            this.addCommand(new _ViewSettingCommand(), {
                widget: ViewSettingsExpandoButton,
                showInGroup: true,
                buttons: [new ViewLanguageButton(), new VisitorGroupButton(), new ChannelsButton()],
                category: "view"
            });

            // Preview expando button
            this.addCommand(new _TogglePreviewModeCommand(), {
                widget: ExpandoButton,
                showInGroup: true,
                hasToggleableChildren: false,
                buttons: [new ContentPane({
                    iconClass: "",
                    "class": "epi-expandoButtonActiveNode",
                    content: "<span>" + resources.toolbar.buttons.togglepreviewmode.message + "</span>"
                })],
                category: "view"
            });

            // this.addCommand(new CompareCommand(), {
            //     widget: ExpandoButton,
            //     hasToggleableChildren: false,
            //     buttons: [new ContentPane({
            //         iconClass: "",
            //         "class": "epi-expandoButtonActiveNode",
            //         content: "<span>" + resources.toolbar.buttons.compare.message + "</span>"
            //     })]
            // });
        },

        _addTrailingCommands: function () {
            this.addToTrailing(new _ToggleAssetsPaneCommand(), {
                widget: ToggleButton,
                "class": "epi-trailingToggleButton epi-mediumButton"
            });
        }
    });
});